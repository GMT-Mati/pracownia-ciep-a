# Pracownia Ciepła — starter

## Uruchomienie

```bash
python -m venv .venv
```

Windows: `.venv\Scripts\activate`

macOS/Linux: `source .venv/bin/activate`

```bash
pip install -r requirements.txt
python app.py
```

Otwórz `http://127.0.0.1:5000`.

## Zawartość
- responsywna strona główna,
- oferta, realizacje, proces i kontakt,
- formularz zapisujący wiadomości do `data/messages.csv`,
- API `/api/projects`,
- podstawowe SEO.
