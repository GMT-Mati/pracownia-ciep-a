from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, render_template, request

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MESSAGES_FILE = DATA_DIR / "messages.csv"

app = Flask(__name__)

PROJECTS = [
    {"title": "Kominek akumulacyjny", "category": "Kominki", "description": "Nowoczesne palenisko z masą akumulacyjną, zaprojektowane jako centralny punkt salonu."},
    {"title": "Piec kaflowy", "category": "Piece", "description": "Tradycyjna forma połączona z nowoczesną techniką spalania i spokojną, ponadczasową bryłą."},
    {"title": "Piec chlebowy", "category": "Kuchnia ogrodowa", "description": "Murowany piec do chleba i pizzy, wykonany z materiałów odpornych na wysoką temperaturę."},
]

@app.get("/")
def home():
    return render_template("index.html", projects=PROJECTS)

@app.get("/api/projects")
def projects():
    return jsonify(PROJECTS)

@app.post("/api/contact")
def contact():
    payload = request.get_json(silent=True) or request.form.to_dict()
    name = str(payload.get("name", "")).strip()
    email = str(payload.get("email", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    message = str(payload.get("message", "")).strip()

    if not name or not email or not message:
        return jsonify({"ok": False, "error": "Uzupełnij imię, e-mail i wiadomość."}), 400

    DATA_DIR.mkdir(exist_ok=True)
    file_exists = MESSAGES_FILE.exists()
    with MESSAGES_FILE.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        if not file_exists:
            writer.writerow(["created_at", "name", "email", "phone", "message"])
        writer.writerow([datetime.now().isoformat(timespec="seconds"), name, email, phone, message])

    return jsonify({"ok": True, "message": "Dziękujemy. Wiadomość została zapisana."})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
